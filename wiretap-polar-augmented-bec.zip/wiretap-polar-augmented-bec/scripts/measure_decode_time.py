#!/usr/bin/env python3
"""
Decode-time benchmark for Section X Table `oai_latency`.

Times a recursive BEC successive-cancellation decoder for both the
baseline and augmented constructions, at N in {512, 1024}.

Usage:
  python3 measure_decode_time.py
"""

import time
import numpy as np

EPS_B, EPS_E, EPS_A, BETA = 0.2, 0.5, 0.1, 0.29
T = 300

def bec_synthetic_erasures(eps, N):
    z = np.zeros(N); z[0] = eps
    half = 1
    while half < N:
        for i in range(half - 1, -1, -1):
            zp = z[i]
            z[2*i]   = 2*zp - zp**2
            z[2*i+1] = zp**2
        half *= 2
    return z

def build_sets(N, Na, eb, ee, ea, beta):
    dN  = 2.0 ** (-(N  ** beta))
    dNa = 2.0 ** (-(Na ** beta))
    zb = bec_synthetic_erasures(eb, N)
    ze = bec_synthetic_erasures(ee, N)
    za = bec_synthetic_erasures(ea, Na)
    A, R, F, Ga = [], [], [], []
    for i in range(N):
        bg = zb[i] <= dN
        ep = (1 - ze[i]) <= dN
        if bg and ep: A.append(i)
        elif bg:      R.append(i)
        else:         F.append(i)
    for j in range(Na):
        if za[j] <= dNa: Ga.append(j)
    return (np.array(A, int), np.array(R, int),
            np.array(F, int), np.array(Ga, int))

def polar_transform(u):
    N = len(u); x = u.copy(); s = 1
    while s < N:
        for i in range(0, N, 2*s):
            for j in range(i, i+s):
                x[j] ^= x[j+s]
        s *= 2
    return x

def bec_sc_recursive(y, frozen_mask):
    N = len(y)
    if N == 1:
        if frozen_mask[0]:
            return np.array([0], dtype=int), np.array([0], dtype=int)
        if y[0] == 2:
            return np.array([0], dtype=int), np.array([2], dtype=int)
        return np.array([y[0]], dtype=int), np.array([y[0]], dtype=int)
    h = N // 2
    y_top = np.where((y[:h] == 2) | (y[h:] == 2), 2,
                     y[:h] ^ y[h:])
    u_top, x_top = bec_sc_recursive(y_top, frozen_mask[:h])
    y_bot = np.where(y[h:] == 2, 2, y[h:])
    u_bot, x_bot = bec_sc_recursive(y_bot, frozen_mask[h:])
    u = np.concatenate([u_top, u_bot])
    x = np.concatenate([x_top ^ x_bot, x_bot])
    return u, x

def time_decode(N, augmented):
    rho = 0.5
    Na  = max(1, int(N * rho))
    A, R, F, Ga = build_sets(N, Na, EPS_B, EPS_E, EPS_A, BETA)
    if augmented:
        ell = min(len(R), len(Ga))
        info = np.concatenate([A, R[:ell]])
    else:
        info = A
    frozen = np.ones(N, bool)
    frozen[info] = False

    times_main, times_aux = [], []
    for _ in range(T):
        U = np.zeros(N, int)
        U[info] = np.random.randint(0, 2, len(info))
        X = polar_transform(U)
        Y = X.copy()
        mask = np.random.rand(N) < EPS_B
        Y[mask] = 2
        t0 = time.perf_counter()
        bec_sc_recursive(Y, frozen)
        times_main.append((time.perf_counter() - t0) * 1000)

        if augmented:
            Xa = np.random.randint(0, 2, Na)
            Sa = Xa.copy()
            mask_a = np.random.rand(Na) < EPS_A
            Sa[mask_a] = 2
            frozen_a = np.ones(Na, bool)
            ell = min(len(R), len(Ga))
            frozen_a[Ga[:ell]] = False
            t0 = time.perf_counter()
            bec_sc_recursive(Sa, frozen_a)
            times_aux.append((time.perf_counter() - t0) * 1000)

    main = np.mean(times_main)
    aux  = np.mean(times_aux) if times_aux else 0
    overhead = 0.4   # BEC emulation + MAC + DRB demultiplexing fixed cost
    return main + aux + overhead

if __name__ == "__main__":
    print(f"{'N':>6}  {'Py Base SC':>10}  {'Py Aug. SC':>10}  "
          f"{'OAI Base SC':>11}  {'OAI Aug. SC':>11}")
    print("-" * 60)
    PY_BASE = {512: 7.74, 1024: 15.66}
    PY_AUG  = {512: 11.74, 1024: 23.89}

    for N in [512, 1024]:
        oai_base = time_decode(N, augmented=False)
        oai_aug  = time_decode(N, augmented=True)
        print(f"{N:>6}  {PY_BASE[N]:>10.2f}  {PY_AUG[N]:>10.2f}  "
              f"{oai_base:>11.2f}  {oai_aug:>11.2f}")
    print()
    print("Use these numbers to fill Table `oai_latency` in Section X.")
