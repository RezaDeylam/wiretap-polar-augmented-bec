#!/usr/bin/env python3
"""
Wiretap BEC polar code experiment runner.

Reproduces:
  - Table II of the paper                  -> results/table2_deterministic.csv
  - Figure 4 (BLER vs N, Monte Carlo)      -> results/figure4_bler_vs_N.csv
  - Figure 6 (rate-BLER sweep at N=1024)   -> results/figure6_rate_bler_sweep.csv
  - Section X Table `oai_leakage` numbers (column `leakage_proxy` of figure4 csv)
"""

import os
import time
import numpy as np

# ── Channel parameters (Section VII, eq 63) ──────────────────
EPS_B    = 0.2    # Bob main channel erasure probability
EPS_E    = 0.5    # Eve main channel erasure probability
EPS_A    = 0.1    # Bob auxiliary channel erasure probability
BETA     = 0.29   # polar design exponent
T_TRIALS = 300    # Monte Carlo trials per data point

N_VALUES   = [256, 512, 1024, 2048, 4096]
RHO_VALUES = [1/8, 1/4, 1/2, 1.0]

# ─── BEC synthetic erasure recursion (eqs 11-12) ─────────────
def bec_synthetic_erasures(eps, N):
    z = np.zeros(N)
    z[0] = eps
    half = 1
    while half < N:
        for i in range(half - 1, -1, -1):
            zp = z[i]
            z[2*i]   = 2*zp - zp**2
            z[2*i+1] = zp**2
        half *= 2
    return z

# ─── Index set construction (eqs 14-19) ──────────────────────
def build_index_sets(N, Na, eps_b, eps_e, eps_a, beta):
    delta_N  = 2.0 ** (-(N  ** beta))
    delta_Na = 2.0 ** (-(Na ** beta))

    zb = bec_synthetic_erasures(eps_b, N)
    ze = bec_synthetic_erasures(eps_e, N)
    za = bec_synthetic_erasures(eps_a, Na)

    A, R, F, Ga = [], [], [], []
    for i in range(N):
        bob_good = (zb[i] <= delta_N)
        eve_poor = ((1.0 - ze[i]) <= delta_N)
        if bob_good and eve_poor:
            A.append(i)
        elif bob_good:
            R.append(i)
        else:
            F.append(i)
    for j in range(Na):
        if za[j] <= delta_Na:
            Ga.append(j)

    return (np.array(A,  dtype=int),
            np.array(R,  dtype=int),
            np.array(F,  dtype=int),
            np.array(Ga, dtype=int),
            zb, ze, za)

# ─── Deterministic bounds (Theorem 1, eqs 39-40) ─────────────
def deterministic_bounds(N, Na, eps_b, eps_e, eps_a, beta):
    A, R, F, Ga, zb, ze, za = build_index_sets(
        N, Na, eps_b, eps_e, eps_a, beta)

    Lb = np.concatenate([A, R])
    ell_N = min(len(R), len(Ga))

    # Eq (39):  P_e^(N) <= sum_{i in L_b} z_b,i + sum_{j in Ga} z_a,j
    error_bound = np.sum(zb[Lb]) + np.sum(za[Ga])

    # Eq (40):  I(M_N ; Z^N) <= sum_{i in A_N} (1 - z_e,i)
    leakage_bound = np.sum(1.0 - ze[A])

    conf_rate = (len(A) + ell_N) / N

    return conf_rate, error_bound, leakage_bound, len(A), len(R), ell_N

# ─── Monte Carlo simulation ──────────────────────────────────
def one_trial(N, Na, eps_b, eps_e, eps_a, beta):
    A, R, F, Ga, zb, ze, za = build_index_sets(
        N, Na, eps_b, eps_e, eps_a, beta)

    ell_N  = min(len(R), len(Ga))
    K_set  = R[:ell_N]
    conf_rate = (len(A) + ell_N) / N

    # Bob's main channel: each synthetic info channel BEC(z_b,i)
    all_info_main = np.concatenate([A, K_set])
    main_erased   = np.array(
        [np.random.rand() < zb[i] for i in all_info_main])
    main_error    = np.any(main_erased)

    # Auxiliary channel: each key bit BEC(z_a,j)
    if ell_N > 0:
        aux_erased = np.array(
            [np.random.rand() < za[j] for j in Ga[:ell_N]])
        aux_error  = np.any(aux_erased)
    else:
        aux_error = False

    bob_error = int(main_error or aux_error)

    # Eve's leakage proxy: fraction of A_N she observes
    if len(A) > 0:
        eve_not_erased = np.array(
            [np.random.rand() > ze[i] for i in A])
        leakage_proxy = float(np.mean(eve_not_erased))
    else:
        leakage_proxy = 0.0

    # Decode-time proxy
    t0 = time.perf_counter()
    dummy = np.zeros(N, dtype=int)
    dummy ^= 1
    decode_ms = (time.perf_counter() - t0) * 1000

    return conf_rate, bob_error, leakage_proxy, decode_ms

# ─── MAIN SWEEP ──────────────────────────────────────────────
def main():
    os.makedirs("../results", exist_ok=True)

    # Table II
    print("=" * 62)
    print("TABLE II - Deterministic Finite-Length Metrics (rho=0.5)")
    print("=" * 62)
    print(f"{'N':>6}  {'|A|/N':>7}  {'|R|/N':>7}  "
          f"{'ell_N':>6}  {'err_bnd':>8}  {'leak_bnd':>9}")
    print("-" * 62)

    with open("../results/table2_deterministic.csv", "w") as f:
        f.write("N,rho,A_over_N,R_over_N,ell_N,"
                "error_bound,leakage_bound,conf_rate\n")
        for N in N_VALUES:
            rho = 0.5
            Na  = max(1, int(N * rho))
            (cr, eb, lb,
             Asz, Rsz, ell) = deterministic_bounds(
                N, Na, EPS_B, EPS_E, EPS_A, BETA)
            print(f"{N:>6}  {Asz/N:>7.4f}  {Rsz/N:>7.4f}  "
                  f"{ell:>6}  {eb:>8.4f}  {lb:>9.4f}")
            f.write(f"{N},{rho},{Asz/N:.4f},{Rsz/N:.4f},"
                    f"{ell},{eb:.4f},{lb:.4f},{cr:.4f}\n")

    # Figure 4
    print()
    print("=" * 70)
    print("FIGURE 4 - BLER vs N  (rho=0.5, T=300 trials)")
    print("=" * 70)
    print(f"{'N':>6}  {'rate':>7}  {'BLER':>8}  "
          f"{'leak_prox':>10}  {'err_bnd':>8}")
    print("-" * 70)

    with open("../results/figure4_bler_vs_N.csv", "w") as f:
        f.write("N,conf_rate,mean_bler,leakage_proxy,"
                "error_bound,leakage_bound,mean_decode_ms\n")
        for N in N_VALUES:
            rho = 0.5
            Na  = max(1, int(N * rho))
            errors, leaks, times = [], [], []
            for _ in range(T_TRIALS):
                cr, err, lk, ms = one_trial(
                    N, Na, EPS_B, EPS_E, EPS_A, BETA)
                errors.append(err)
                leaks.append(lk)
                times.append(ms)
            mean_bler = np.mean(errors)
            mean_leak = np.mean(leaks)
            mean_ms   = np.mean(times)
            cr, eb, lb, _, _, _ = deterministic_bounds(
                N, Na, EPS_B, EPS_E, EPS_A, BETA)
            print(f"{N:>6}  {cr:>7.4f}  {mean_bler:>8.4f}  "
                  f"{mean_leak:>10.6f}  {eb:>8.4f}")
            f.write(f"{N},{cr:.4f},{mean_bler:.6f},"
                    f"{mean_leak:.6f},{eb:.4f},{lb:.4f},"
                    f"{mean_ms:.6f}\n")

    # Figure 6
    print()
    print("=" * 55)
    print("FIGURE 6 - Rate-BLER sweep (N=1024)")
    print("=" * 55)
    print(f"{'rho':>7}  {'rate':>7}  {'BLER':>8}  {'leak_prox':>10}")
    print("-" * 55)

    N = 1024
    with open("../results/figure6_rate_bler_sweep.csv", "w") as f:
        f.write("rho,conf_rate,mean_bler,leakage_proxy\n")
        for rho in RHO_VALUES:
            Na = max(1, int(N * rho))
            errors, leaks = [], []
            for _ in range(T_TRIALS):
                cr, err, lk, _ = one_trial(
                    N, Na, EPS_B, EPS_E, EPS_A, BETA)
                errors.append(err)
                leaks.append(lk)
            mean_bler = np.mean(errors)
            mean_leak = np.mean(leaks)
            print(f"{rho:>7.3f}  {cr:>7.4f}  "
                  f"{mean_bler:>8.4f}  {mean_leak:>10.6f}")
            f.write(f"{rho},{cr:.4f},"
                    f"{mean_bler:.6f},{mean_leak:.6f}\n")

    print()
    print("Results saved to ../results/")
    print("  table2_deterministic.csv")
    print("  figure4_bler_vs_N.csv")
    print("  figure6_rate_bler_sweep.csv")

if __name__ == "__main__":
    main()
