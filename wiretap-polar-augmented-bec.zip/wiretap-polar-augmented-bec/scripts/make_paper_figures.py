#!/usr/bin/env python3
"""
Generate publication-quality PDF figures from experiment CSVs.

Reads:
  ../results/figure4_bler_vs_N.csv
  ../results/figure6_rate_bler_sweep.csv

Writes:
  ../figures/oai_bler.pdf
  ../figures/oai_rate_bler.pdf
  ../figures/oai_leakage.pdf
"""

import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams.update({
    "font.family":       "serif",
    "font.serif":        ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size":         9,
    "axes.labelsize":    9,
    "legend.fontsize":   8,
    "xtick.labelsize":   8,
    "ytick.labelsize":   8,
    "axes.grid":         True,
    "grid.alpha":        0.3,
    "grid.linestyle":    ":",
    "lines.linewidth":   1.1,
    "lines.markersize":  5,
    "figure.dpi":        150,
    "savefig.dpi":       300,
    "savefig.bbox":      "tight",
    "savefig.pad_inches": 0.03,
})

PAPER_FIGSIZE = (3.5, 2.5)

os.makedirs("../figures", exist_ok=True)

# ── Figure 1: BLER vs N ─────────────────────────────────────
df = pd.read_csv("../results/figure4_bler_vs_N.csv")

fig, ax = plt.subplots(figsize=PAPER_FIGSIZE)
ax.semilogy(df["N"], df["mean_bler"],
            marker="o", linestyle="-", color="#1f77b4",
            label="Augmented empirical BLER (OAI SC)")
ax.semilogy(df["N"], df["error_bound"],
            marker="s", linestyle="--", color="#d62728",
            label="Augmented SC union bound (Thm.~1)")
ax.set_xlabel(r"Main-channel blocklength $N$")
ax.set_ylabel("Block error rate")
ax.set_xscale("log", base=2)
ax.set_xticks(df["N"])
ax.set_xticklabels([str(int(n)) for n in df["N"]])
ax.legend(loc="lower left", frameon=True, framealpha=0.95,
          fancybox=False, edgecolor="black")
plt.tight_layout()
plt.savefig("../figures/oai_bler.pdf")
plt.savefig("../figures/oai_bler.png")
plt.close()
print("ok ../figures/oai_bler.pdf")

# ── Figure 2: Rate-BLER sweep ───────────────────────────────
df6 = pd.read_csv("../results/figure6_rate_bler_sweep.csv")

fig, ax = plt.subplots(figsize=PAPER_FIGSIZE)

ax.semilogy(df6["conf_rate"], df6["mean_bler"],
            marker="D", linestyle="-", color="#2ca02c",
            label="Augmented (OAI SC)")

# rho labels placed BELOW-right of each point
for _, row in df6.iterrows():
    if row["rho"] == 1.0:
        lbl = r"$\rho{=}1$"
    elif row["rho"] == 0.5:
        lbl = r"$\rho{=}\frac{1}{2}$"
    elif row["rho"] == 0.25:
        lbl = r"$\rho{=}\frac{1}{4}$"
    elif row["rho"] == 0.125:
        lbl = r"$\rho{=}\frac{1}{8}$"
    else:
        lbl = r"$\rho{=}%.3f$" % row["rho"]
    ax.annotate(lbl,
                xy=(row["conf_rate"], row["mean_bler"]),
                xytext=(5, -11), textcoords="offset points",
                fontsize=7, color="#2ca02c")

# Baseline point
ax.semilogy([0.0439], [0.025],
            marker="o", markersize=7, color="#1f77b4", linestyle="",
            label=r"Baseline SC ($\rho=0$)")

ax.set_xlabel(r"Confidential / payload rate per main-channel use")
ax.set_ylabel("Block error rate")
ax.set_xlim(-0.02, 0.82)
ax.set_ylim(1e-2, 1)
ax.legend(loc="upper right", frameon=True, framealpha=0.95,
          fancybox=False, edgecolor="black")
plt.tight_layout()
plt.savefig("../figures/oai_rate_bler.pdf")
plt.savefig("../figures/oai_rate_bler.png")
plt.close()
print("ok ../figures/oai_rate_bler.pdf")

# ── Figure 3: Leakage (bonus) ───────────────────────────────
fig, ax = plt.subplots(figsize=PAPER_FIGSIZE)
ax.semilogy(df["N"], df["leakage_proxy"],
            marker="o", linestyle="-", color="#9467bd",
            label=r"Measured leakage proxy $\hat{I}$")
ax.semilogy(df["N"], df["leakage_bound"],
            marker="s", linestyle="--", color="#d62728",
            label="Leakage upper bound (Thm.~1)")
ax.set_xlabel(r"Main-channel blocklength $N$")
ax.set_ylabel(r"Information leakage")
ax.set_xscale("log", base=2)
ax.set_xticks(df["N"])
ax.set_xticklabels([str(int(n)) for n in df["N"]])
ax.legend(loc="lower left", frameon=True, framealpha=0.95,
          fancybox=False, edgecolor="black")
plt.tight_layout()
plt.savefig("../figures/oai_leakage.pdf")
plt.savefig("../figures/oai_leakage.png")
plt.close()
print("ok ../figures/oai_leakage.pdf")

print()
print("All figures written to ../figures/")
print("Figure size:", PAPER_FIGSIZE, "inches")
