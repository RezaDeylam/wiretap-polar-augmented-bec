#!/usr/bin/env python3
"""
Core BEC polar code routines used throughout the repository.

This module is imported by the main experiment scripts. It is also a
self-contained reference implementation of the BEC erasure recursion,
the index-set construction (Algorithm 2 of the paper), and the
augmented polar encoder (Algorithm 1 of the paper).
"""

import numpy as np


def bec_synthetic_erasures(eps: float, N: int) -> np.ndarray:
    """
    Compute synthetic erasure probabilities for a BEC(eps) under a polar
    transform of length N (eqs 11-12 of the paper).

    Parameters
    ----------
    eps : float in [0, 1]
        Erasure probability of the underlying BEC.
    N : int
        Block-length (must be a power of two).

    Returns
    -------
    z : ndarray of shape (N,)
        Synthetic erasure probabilities z_i for i = 0, ..., N-1.
    """
    z = np.zeros(N)
    z[0] = eps
    half = 1
    while half < N:
        for i in range(half - 1, -1, -1):
            zp = z[i]
            z[2*i]     = 2*zp - zp**2   # eq (11)
            z[2*i + 1] = zp**2           # eq (12)
        half *= 2
    return z


def build_index_sets(N: int, Na: int,
                     eps_b: float, eps_e: float, eps_a: float,
                     beta: float):
    """
    Build the BEC-specialized index sets (eqs 14-19 of the paper).

    Returns
    -------
    A, R, F, Ga : ndarray of int
        Secure, Bob-good/Eve-good, frozen, and reliable-aux index sets.
    zb, ze, za : ndarray of float
        Synthetic erasure probability vectors.
    """
    delta_N  = 2.0 ** (-(N  ** beta))
    delta_Na = 2.0 ** (-(Na ** beta))

    zb = bec_synthetic_erasures(eps_b, N)
    ze = bec_synthetic_erasures(eps_e, N)
    za = bec_synthetic_erasures(eps_a, Na)

    A, R, F, Ga = [], [], [], []
    for i in range(N):
        bob_good = (zb[i] <= delta_N)
        eve_poor = ((1.0 - ze[i]) <= delta_N)
        if bob_good and eve_poor:
            A.append(i)
        elif bob_good:
            R.append(i)
        else:
            F.append(i)
    for j in range(Na):
        if za[j] <= delta_Na:
            Ga.append(j)

    return (np.array(A,  dtype=int),
            np.array(R,  dtype=int),
            np.array(F,  dtype=int),
            np.array(Ga, dtype=int),
            zb, ze, za)


def polar_transform(u: np.ndarray) -> np.ndarray:
    """
    Apply the standard polar transform X = U * G_N (eq 35).
    """
    N = len(u)
    x = u.copy()
    step = 1
    while step < N:
        for i in range(0, N, 2*step):
            for j in range(i, i+step):
                x[j] ^= x[j+step]
        step *= 2
    return x


def augmented_polar_encode(msg_s, msg_k, key, A, K_set, Rr, F, N):
    """
    Algorithm 1 of the paper.

    Parameters
    ----------
    msg_s : ndarray of int
        Physically secure message bits placed on A_N.
    msg_k : ndarray of int
        Helper-protected message bits placed on K_set.
    key : ndarray of int
        Auxiliary-derived key bits used to OTP-encrypt msg_k.
    A, K_set, Rr, F : ndarray of int
        Index sets.
    N : int
        Main block-length.

    Returns
    -------
    X : ndarray of int
        The transmitted main codeword.
    """
    U = np.zeros(N, dtype=int)
    cipher = (msg_k ^ key) if len(msg_k) > 0 else np.array([], dtype=int)

    if len(A) > 0:
        U[A] = msg_s
    if len(K_set) > 0:
        U[K_set] = cipher
    if len(Rr) > 0:
        U[Rr] = np.random.randint(0, 2, len(Rr))
    if len(F) > 0:
        U[F] = 0

    return polar_transform(U)
