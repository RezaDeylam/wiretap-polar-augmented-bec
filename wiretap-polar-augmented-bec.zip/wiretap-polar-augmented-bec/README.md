# Companion Code: Augmented Wiretap BEC Polar Code

**Paper:** *Finite-block-length Polar Code Design and SDR Validation for an
Augmented Degraded Wiretap BEC With a Bob-Only Auxiliary Channel*

**Author:** Mohammad Reza Deylam Salehi
([reza.deylam@ieee.org](mailto:reza.deylam@ieee.org))

This repository contains all companion scripts and OpenAirInterface5G
configuration files used to reproduce the deterministic curves, Monte Carlo
experiments, OpenAirInterface5G (OAI) RF-simulator results, and figures of
the paper.

---

## What this code does

The paper proposes a *key-assisted polar coding* scheme for a degraded
wiretap binary erasure channel (BEC) augmented by a Bob-only auxiliary BEC.
The auxiliary channel transports a one-time-pad key, which is then consumed
by the main polar code to convert Eve-good polarized indices into
confidential-message positions.

The code in this repository:

1. Computes synthetic erasure probabilities via the BEC recursion.
2. Builds the index sets `A_N`, `R_N`, `F_N`, and `Ga(N_a)`.
3. Evaluates the deterministic finite-length error and leakage bounds of
   Theorem 1.
4. Runs Monte Carlo simulations of the full encoding/decoding chain.
5. Reproduces all numerical results in Tables II-III and Figures 4, 6 of
   the paper, plus the OAI-section results in Section X (Table II of
   Section X, Figures `oai_bler`, `oai_rate_bler`, `oai_leakage`,
   Table `oai_latency`).
6. Provides drop-in OAI configuration files for the gNB, Bob's UE, and
   Eve's UE used in the SDR proof-of-concept of Section X.

---

## Repository layout

```
wiretap-polar-augmented-bec/
├── README.md                          # this file
├── LICENSE                            # MIT license
├── requirements.txt                   # Python dependencies
│
├── scripts/                           # Python reproducibility scripts
│   ├── run_wiretap_experiment.py      # Generates Tables II/III + Figures 4/6 data
│   ├── make_paper_figures.py          # Renders figures from CSV results
│   ├── measure_decode_time.py         # Decode-time benchmark (Table III ext.)
│   └── bec_polar_engine.py            # Core BEC polar code routines
│
├── oai_configs/                       # OpenAirInterface5G configurations
│   ├── gnb_wiretap.conf               # Alice / gNB configuration
│   ├── ue_bob.conf                    # Bob / UE1 configuration (main + aux DRBs)
│   ├── ue_eve.conf                    # Eve / UE2 configuration (main DRB only)
│   └── README_oai.md                  # OAI-specific build/launch instructions
│
├── figures/                           # Generated figures (after running scripts)
└── results/                           # Generated CSVs (after running scripts)
```

---

## Quick start

### Requirements

* Python ≥ 3.8
* numpy, pandas, matplotlib

Install dependencies:

```bash
pip3 install -r requirements.txt
```

(On Ubuntu 22.04+, you may need `--break-system-packages` after `pip3 install`.)

### Reproduce the paper's figures and tables

Run the experiments (5-15 minutes on a typical laptop):

```bash
cd scripts/
python3 run_wiretap_experiment.py
```

This produces three CSV files under `results/`:

| File | Reproduces |
| :--- | :--- |
| `table2_deterministic.csv` | Table II of the paper |
| `figure4_bler_vs_N.csv` | Figure 4 + Table `oai_leakage` |
| `figure6_rate_bler_sweep.csv` | Figure 6 |

Then render publication-quality PDF figures:

```bash
python3 make_paper_figures.py
```

This writes `figures/oai_bler.pdf`, `figures/oai_rate_bler.pdf`, and
`figures/oai_leakage.pdf` (the bonus figure).

To benchmark decoding latency for the OAI-section table:

```bash
python3 measure_decode_time.py
```

---

## Reproducibility checklist

| Paper element | Script | Output |
| :--- | :--- | :--- |
| Table II (deterministic metrics) | `run_wiretap_experiment.py` | `results/table2_deterministic.csv` |
| Figure 4 (BLER vs N, Monte Carlo) | `run_wiretap_experiment.py` | `results/figure4_bler_vs_N.csv` |
| Figure 6 (rate-BLER sweep) | `run_wiretap_experiment.py` | `results/figure6_rate_bler_sweep.csv` |
| Section X Figure `oai_bler` | `make_paper_figures.py` | `figures/oai_bler.pdf` |
| Section X Figure `oai_rate_bler` | `make_paper_figures.py` | `figures/oai_rate_bler.pdf` |
| Section X Figure `oai_leakage` | `make_paper_figures.py` | `figures/oai_leakage.pdf` |
| Section X Table `oai_leakage` | `figure4_bler_vs_N.csv`, column `leakage_proxy` | (manual transcription) |
| Section X Table `oai_latency` | `measure_decode_time.py` | console output |

---

## OpenAirInterface5G testbed

The OAI configuration files in `oai_configs/` reproduce the SDR
proof-of-concept of Section X. They are designed for OAI's RF-simulator
mode and require no physical radio hardware.

See `oai_configs/README_oai.md` for build instructions and the launch
sequence.

**Note.** The polar PHY module integrated into the OAI source tree is not
distributed as a fork in this repository because OAI is updated frequently
and a fork would quickly become stale. The C source files for the custom
polar PHY module are described in the paper (Section X, "Custom Polar PHY
Module"). They live under
`openairinterface5g/openair1/PHY/CODING/wiretap_polar/` in the modified OAI
tree and follow the BEC polar engine implemented in
`scripts/bec_polar_engine.py`. To replicate the C integration, re-implement
the three routines (`bec_synthetic_erasures`, `build_index_sets`,
`augmented_polar_encode`) directly in C and hook them into OAI's PDSCH
encoding pipeline as documented in the paper.

---

## Default channel parameters

Unless overridden, all scripts use the parameters of equation (63) of the
paper:

| Parameter | Value | Meaning |
| :--- | ---: | :--- |
| `EPS_B` | 0.2 | Bob main-channel erasure probability |
| `EPS_E` | 0.5 | Eve main-channel erasure probability |
| `EPS_A` | 0.1 | Bob auxiliary-channel erasure probability |
| `BETA` | 0.29 | Polar design exponent |
| `T_TRIALS` | 300 | Monte Carlo trials per data point |

To change them, edit the constants at the top of
`scripts/run_wiretap_experiment.py`.

---

## How to cite

If you use this code, please cite the paper:

```bibtex
@article{deylam2026augmented,
  author  = {Deylam Salehi, Mohammad Reza},
  title   = {Finite-block-length Polar Code Design and SDR Validation
             for an Augmented Degraded Wiretap BEC With a Bob-Only
             Auxiliary Channel},
  journal = {[journal name]},
  year    = {2026},
  note    = {Companion code: \url{https://github.com/[your-username]/wiretap-polar-augmented-bec}}
}
```

---

## License

This repository is released under the **MIT License**. See `LICENSE` for
details. You are free to use, modify, and redistribute the code, provided
that the copyright notice is preserved.

---

## Contact

For questions, suggestions, or bug reports, please open an issue on the
repository or contact the author at
[reza.deylam@ieee.org](mailto:reza.deylam@ieee.org).
