# OAI Testbed — Build and Launch Instructions

This document describes how to build OpenAirInterface5G (OAI) and launch
the three software processes (gNB, Bob's UE, Eve's UE) used in the SDR
proof-of-concept of Section X of the paper.

No physical radio hardware is required: all three processes communicate
via OAI's built-in RF simulator.

---

## 1. System requirements

* Ubuntu 22.04 LTS (recommended) or 24.04 LTS
* RAM: ≥ 16 GB
* CPU: ≥ 4 cores
* Disk: ≥ 40 GB free
* `sudo` privileges (required by OAI for kernel-level networking)

---

## 2. Build OAI

### 2.1 Install base dependencies

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y git cmake build-essential libsctp-dev \
    python3 python3-pip libfftw3-dev libconfig-dev \
    net-tools iperf3 tshark
```

### 2.2 Clone OAI

```bash
cd ~
git clone https://gitlab.eurecom.fr/oai/openairinterface5g.git
cd openairinterface5g
git checkout develop
```

### 2.3 Run the OAI dependency installer

```bash
cd ~/openairinterface5g/cmake_targets
./build_oai -I
```

(10–20 minutes)

### 2.4 Build gNB and UE binaries with the RF simulator

```bash
cd ~/openairinterface5g/cmake_targets
./build_oai --gNB --nrUE -w SIMU --ninja -C
```

(another 10–15 minutes)

When complete, verify:

```bash
ls ~/openairinterface5g/cmake_targets/ran_build/build/
# Expected: nr-softmodem  nr-uesoftmodem
```

---

## 3. Integrate the custom polar PHY module

The Section X experiment requires a small custom C module under
`openair1/PHY/CODING/wiretap_polar/`. The Python reference
implementation in `../scripts/bec_polar_engine.py` defines the same
three routines that need to be re-implemented in C for the OAI tree:

| Python routine | C routine |
| :--- | :--- |
| `bec_synthetic_erasures` | `compute_synthetic_erasures` |
| `build_index_sets` | `build_index_sets` |
| `augmented_polar_encode` | `augmented_polar_encode` |

The custom module must be hooked between the MAC PDU handler and the
PDSCH modulator in
`openair1/PHY/NR_TRANSPORT/nr_dlsch_coding.c`,
replacing OAI's standard LDPC pipeline only for the experimental DRBs.

---

## 4. Place configuration files

Copy the three configuration files in this folder into a convenient
directory readable by the OAI binaries, e.g.:

```bash
mkdir -p ~/wiretap_oai_configs
cp gnb_wiretap.conf ue_bob.conf ue_eve.conf ~/wiretap_oai_configs/
```

---

## 5. Launch sequence (three terminals)

### Terminal 1 — Alice (gNB)

```bash
cd ~/openairinterface5g/cmake_targets/ran_build/build
sudo ./nr-softmodem \
  -O ~/wiretap_oai_configs/gnb_wiretap.conf \
  --rfsim \
  --log_config.global_log_options level,nocolor
```

Wait until the gNB log shows `[MAC] DLSCH: Initial RA succeeded`.

### Terminal 2 — Bob (UE 1)

```bash
cd ~/openairinterface5g/cmake_targets/ran_build/build
sudo ./nr-uesoftmodem \
  -O ~/wiretap_oai_configs/ue_bob.conf \
  --rfsim \
  --rfsimulator.serveraddr 127.0.0.1
```

Wait until Bob registers with the gNB and DRB1 + DRB2 become active.

### Terminal 3 — Eve (UE 2)

```bash
cd ~/openairinterface5g/cmake_targets/ran_build/build
sudo ./nr-uesoftmodem \
  -O ~/wiretap_oai_configs/ue_eve.conf \
  --rfsim \
  --rfsimulator.serveraddr 127.0.0.1
```

Eve should register only on DRB1; the gNB scheduler must not allocate
PRB resources on DRB2 to Eve's IMSI.

---

## 6. Collect measurements

The custom PHY module logs per-block measurements to a CSV file. After
running each configuration, the resulting CSV can be processed by
`../scripts/make_paper_figures.py` together with the Python-side
results to render the OAI figures of Section X.

---

## 7. Troubleshooting

* **`Permission denied` when launching:** OAI requires `sudo` for the
  kernel-level network setup. Always launch `nr-softmodem` and
  `nr-uesoftmodem` with `sudo`.
* **gNB hangs at "waiting for AMF":** the configuration uses a local
  loopback AMF address (`127.0.0.5`); ensure no other process is bound
  to that address, or update `amf_ip_address` to point at a running
  Open5GS or OAI-CN5G instance.
* **UEs cannot connect to RF simulator:** check that the gNB is
  running first and listening on TCP port 4043; confirm with
  `sudo netstat -ltnp | grep 4043`.
* **DRB2 visible to Eve:** the gNB scheduler must enforce
  IMSI-based filtering. Verify the QoS/scheduling configuration in
  `gnb_wiretap.conf`.
